# Dicoding Collection Dashboard ✨

## Setup environment

conda create --name main-ds python=3.9
conda activate main-ds
pip install numpy pandas matplotlib seaborn jupyter streamlit

## Run steamlit app

streamlit run testbike.py
